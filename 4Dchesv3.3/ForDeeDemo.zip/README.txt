Click the unicorn on the menu to go to the demo!
No further For Dee updates will be included in this as it will be released as it's own game.
This demo version (V0.0.0) includes redstone-like wires, HGens which are give off power if nothing around them is powered, paravoxes, pushable voxes, and walls (although walls are not placeable).

Movement:
WASDQESpaceShift

Toggle pushing of voxes and paravoxes:
P

Place vox in hand after next move:
Enter

Destroy vox in destination space on next move:
Backspace

Change Item In Hand:
1,2,3,4,5

Open commanline:
Backslash

Commands:
help hypervox - show help menu for the demo controlls
ls - list saved worlds
save <world name> - save the current world with the specified name (may ovewrite worlds saved with the same name as specified)
load <world name> - loads the world with the specified name